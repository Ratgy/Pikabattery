package com.jjigaemi.pikabattery;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import java.util.Random;

/** 캐릭터 주변에 튀는 작은 번개 스파크. 충전 중에만 돈다. */
public class SparkView extends View {
    private static final int TICK = 70;
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final float[][] bolts = new float[8][];   // x, y, angle, len, life
    private boolean running;
    private long burstUntil;

    public SparkView(Context c) {
        super(c);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setStrokeJoin(Paint.Join.ROUND);
        glow.setColor(0x9966E0FF);
        core.set(glow);
        core.setColor(0xFFFFF27A);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            step();
            invalidate();
            postDelayed(this, TICK);
        }
    };

    void start() { if (!running) { running = true; post(tick); } }
    void stop() { running = false; removeCallbacks(tick); for (int i = 0; i < bolts.length; i++) bolts[i] = null; invalidate(); }
    /** 충전기 꽂은 순간: 아래에서 위로 전기가 확 올라오는 연출 */
    void burst() { burstUntil = System.currentTimeMillis() + 800; start(); }

    private void step() {
        boolean bursting = System.currentTimeMillis() < burstUntil;
        int max = bursting ? 8 : 3;
        float w = getWidth(), h = getHeight();
        for (int i = 0; i < bolts.length; i++) {
            float[] b = bolts[i];
            if (b != null) {
                b[4] -= 1;
                if (bursting) b[1] -= h * 0.08f;   // 위로 올라감
                if (b[4] <= 0) bolts[i] = null;
            }
        }
        int alive = 0;
        for (float[] b : bolts) if (b != null) alive++;
        for (int i = 0; i < bolts.length && alive < max; i++) {
            if (bolts[i] != null || rnd.nextFloat() > (bursting ? 0.9f : 0.35f)) continue;
            float x, y;
            if (bursting) { x = w * (0.15f + rnd.nextFloat() * 0.7f); y = h * (0.75f + rnd.nextFloat() * 0.25f); }
            else {
                // 몸 가장자리 쪽에 주로 생기도록
                boolean side = rnd.nextBoolean();
                x = side ? (rnd.nextBoolean() ? w * 0.1f : w * 0.9f) : w * (0.2f + rnd.nextFloat() * 0.6f);
                y = side ? h * (0.2f + rnd.nextFloat() * 0.7f) : (rnd.nextBoolean() ? h * 0.12f : h * 0.92f);
            }
            float ang = bursting ? (float) (-Math.PI / 2 + (rnd.nextFloat() - 0.5f) * 0.8f)
                                 : (float) (rnd.nextFloat() * Math.PI * 2);
            bolts[i] = new float[]{x, y, ang, Math.min(w, h) * (0.14f + rnd.nextFloat() * 0.12f), 2 + rnd.nextInt(3)};
            alive++;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        glow.setStrokeWidth(Math.max(2f, s * 0.07f));
        core.setStrokeWidth(Math.max(1f, s * 0.03f));
        Path p = new Path();
        for (float[] b : bolts) {
            if (b == null) continue;
            p.reset();
            p.moveTo(b[0], b[1]);
            float x = b[0], y = b[1];
            int seg = 3;
            for (int k = 1; k <= seg; k++) {
                float d = b[3] / seg;
                float jitter = (k % 2 == 0 ? 1 : -1) * d * 0.6f;
                x += (float) Math.cos(b[2]) * d + (float) -Math.sin(b[2]) * jitter;
                y += (float) Math.sin(b[2]) * d + (float) Math.cos(b[2]) * jitter;
                p.lineTo(x, y);
            }
            c.drawPath(p, glow);
            c.drawPath(p, core);
        }
    }
}
