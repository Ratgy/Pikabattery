package com.jjigaemi.pikabattery;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 숫자 + 캐릭터 + 스파크. 상태바와 앱 미리보기가 똑같이 이 뷰를 씀 */
public class BatteryBadge extends LinearLayout {
    private final TextView num;
    private final FrameLayout stack;
    private final ImageView pika;
    private final SparkView spark;
    private final float zoom;           // 미리보기 확대 배율 (상태바는 1)
    private int level = 100;
    private boolean charging;
    private boolean sparksOn = true;

    public BatteryBadge(Context c, float zoom) {
        super(c);
        this.zoom = zoom;
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setClipChildren(false);
        setClipToPadding(false);

        num = new TextView(c);
        num.setTypeface(Typeface.DEFAULT_BOLD);
        num.setIncludeFontPadding(false);
        LayoutParams nlp = new LayoutParams(-2, -2);
        nlp.rightMargin = dp(1);
        addView(num, nlp);

        stack = new FrameLayout(c);
        stack.setClipChildren(false);
        pika = new ImageView(c);
        pika.setScaleType(ImageView.ScaleType.FIT_CENTER);
        spark = new SparkView(c);
        stack.addView(pika, new FrameLayout.LayoutParams(-1, -1));
        stack.addView(spark, new FrameLayout.LayoutParams(-1, -1));
        addView(stack, new LayoutParams(dp(Frames.D_SIZE), dp(Frames.D_SIZE)));
        render();
    }

    void applyPrefs(SharedPreferences p) {
        int size = p.getInt(Frames.K_SIZE, Frames.D_SIZE);
        LayoutParams slp = (LayoutParams) stack.getLayoutParams();
        slp.width = dp(size);
        slp.height = dp(size);
        stack.setLayoutParams(slp);

        boolean dark = p.getBoolean(Frames.K_DARK, false);
        num.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.getInt(Frames.K_TEXT, Frames.D_TEXT) * zoom);
        num.setTextColor(dark ? Color.BLACK : Color.WHITE);
        num.setShadowLayer(dp(1), 0, 0, dark ? 0x66FFFFFF : 0x99000000);
        num.setVisibility(p.getBoolean(Frames.K_SHOW_NUM, true) ? VISIBLE : GONE);

        sparksOn = p.getBoolean(Frames.K_SPARK, true);
        if (charging && sparksOn) spark.start(); else spark.stop();
    }

    void setLevel(int l) { level = l; render(); }

    /** animate=true면 충전기 꽂는 순간 연출(톡 튀고 + 전기가 아래에서 위로) */
    void setCharging(boolean on, boolean animate) {
        boolean changed = on != charging;
        charging = on;
        render();
        if (!on) { spark.stop(); return; }
        if (!sparksOn) return;
        if (animate && changed) {
            stack.animate().cancel();
            stack.setScaleX(1f); stack.setScaleY(1f);
            stack.animate().scaleX(1.2f).scaleY(1.2f).setDuration(110)
                    .withEndAction(() -> stack.animate().scaleX(1f).scaleY(1f).setDuration(220).start())
                    .start();
            spark.burst();
        } else {
            spark.start();
        }
    }

    private void render() {
        pika.setImageResource(Frames.IDS[Frames.indexFor(level)]);
        num.setText((charging ? "⚡" : "") + level);
    }

    @Override
    protected void onDetachedFromWindow() {
        spark.stop();
        super.onDetachedFromWindow();
    }

    int dp(float v) {
        return (int) (v * zoom * getResources().getDisplayMetrics().density + 0.5f);
    }
}
