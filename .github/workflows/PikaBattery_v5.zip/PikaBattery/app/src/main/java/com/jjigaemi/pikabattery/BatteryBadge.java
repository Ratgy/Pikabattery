package com.jjigaemi.pikabattery;

import android.content.Context;
import android.animation.ValueAnimator;
import android.content.SharedPreferences;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 숫자 + 캐릭터 + 스파크. 상태바와 앱 미리보기가 똑같이 이 뷰를 씀 */
public class BatteryBadge extends LinearLayout {
    private final TextView num;
    private final FrameLayout stack;
    private final ImageView pika;
    private final SparkView spark, aura;
    private final float zoom;           // 미리보기 확대 배율 (상태바는 1)
    private int level = 100;
    private boolean charging;
    private boolean sparksOn = true;
    private ValueAnimator glowAnim;

    public BatteryBadge(Context c, float zoom) {
        super(c);
        this.zoom = zoom;
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setClipChildren(false);
        setClipToPadding(false);

        num = new TextView(c);
        num.setTypeface(Typeface.DEFAULT_BOLD);
        num.setIncludeFontPadding(false);
        LayoutParams nlp = new LayoutParams(-2, -2);
        nlp.rightMargin = dp(1);
        addView(num, nlp);

        stack = new FrameLayout(c);
        stack.setClipChildren(false);
        pika = new ImageView(c);
        pika.setScaleType(ImageView.ScaleType.FIT_CENTER);
        spark = new SparkView(c, false);
        aura = new SparkView(c, true);
        stack.addView(aura, new FrameLayout.LayoutParams(-1, -1));   // 캐릭터 뒤 오라
        stack.addView(pika, new FrameLayout.LayoutParams(-1, -1));
        stack.addView(spark, new FrameLayout.LayoutParams(-1, -1));
        addView(stack, new LayoutParams(dp(Frames.D_SIZE), dp(Frames.D_SIZE)));
        render();
    }

    void applyPrefs(SharedPreferences p) {
        int size = p.getInt(Frames.K_SIZE, Frames.D_SIZE);
        LayoutParams slp = (LayoutParams) stack.getLayoutParams();
        slp.width = dp(size);
        slp.height = dp(size);
        stack.setLayoutParams(slp);

        boolean dark = p.getBoolean(Frames.K_DARK, false);
        num.setTextSize(TypedValue.COMPLEX_UNIT_SP, p.getInt(Frames.K_TEXT, Frames.D_TEXT) * zoom);
        num.setTextColor(dark ? Color.BLACK : Color.WHITE);
        num.setShadowLayer(dp(1), 0, 0, dark ? 0x66FFFFFF : 0x99000000);
        num.setVisibility(p.getBoolean(Frames.K_SHOW_NUM, true) ? VISIBLE : GONE);

        sparksOn = p.getBoolean(Frames.K_SPARK, true);
        if (charging && sparksOn) { spark.start(); aura.start(); } else { spark.stop(); aura.stop(); }
        if (charging) startYellow(); else stopYellow();
    }

    void setLevel(int l) { level = l; render(); }

    /** animate=true면 충전기 꽂는 순간 연출(톡 튀고 + 전기가 아래에서 위로) */
    void setCharging(boolean on, boolean animate) {
        boolean changed = on != charging;
        charging = on;
        render();
        if (!on) { spark.stop(); aura.stop(); stopYellow(); return; }
        startYellow();
        if (!sparksOn) return;
        if (animate && changed) {
            stack.animate().cancel();
            stack.setScaleX(1f); stack.setScaleY(1f);
            stack.animate().scaleX(1.2f).scaleY(1.2f).setDuration(110)
                    .withEndAction(() -> stack.animate().scaleX(1f).scaleY(1f).setDuration(220).start())
                    .start();
            spark.burst();
            aura.burst();
        } else {
            spark.start();
            aura.start();
        }
    }

    /** 충전 중: 캐릭터가 노랗게 서서히 물들었다가 다시 돌아오기를 반복 */
    private void startYellow() {
        if (glowAnim != null) return;
        glowAnim = ValueAnimator.ofFloat(0f, 1f);
        glowAnim.setDuration(1400);
        glowAnim.setRepeatMode(ValueAnimator.REVERSE);
        glowAnim.setRepeatCount(ValueAnimator.INFINITE);
        glowAnim.addUpdateListener(a -> tintYellow((float) a.getAnimatedValue() * 0.85f));
        glowAnim.start();
    }

    private void stopYellow() {
        if (glowAnim == null) return;
        glowAnim.cancel();
        glowAnim = null;
        // 꺼질 때도 부드럽게 원래 색으로
        float from = currentTint;
        ValueAnimator back = ValueAnimator.ofFloat(from, 0f);
        back.setDuration(400);
        back.addUpdateListener(a -> tintYellow((float) a.getAnimatedValue()));
        back.start();
    }

    private float currentTint;

    /** t=0 원래 색, t=1 노란 피카츄 색 (검은 외곽선·눈은 그대로 유지) */
    private void tintYellow(float t) {
        currentTint = t;
        if (t <= 0.001f) { pika.clearColorFilter(); return; }
        float r = 1f, g = 1f - t * 0.12f, b = 1f - t * 0.85f;
        ColorMatrix m = new ColorMatrix(new float[]{
                r, 0, 0, 0, t * 10,
                0, g, 0, 0, t * 6,
                0, 0, b, 0, 0,
                0, 0, 0, 1, 0});
        pika.setColorFilter(new ColorMatrixColorFilter(m));
    }

    private void render() {
        pika.setImageResource(Frames.IDS[Frames.indexFor(level)]);
        num.setText((charging ? "⚡" : "") + level);
    }

    @Override
    protected void onDetachedFromWindow() {
        spark.stop();
        aura.stop();
        if (glowAnim != null) { glowAnim.cancel(); glowAnim = null; }
        super.onDetachedFromWindow();
    }

    int dp(float v) {
        return (int) (v * zoom * getResources().getDisplayMetrics().density + 0.5f);
    }
}
