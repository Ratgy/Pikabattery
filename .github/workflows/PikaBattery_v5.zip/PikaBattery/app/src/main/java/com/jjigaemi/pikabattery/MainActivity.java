package com.jjigaemi.pikabattery;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    private static final float ZOOM = 2f;   // 미리보기는 실제 상태바의 2배 크기

    private SharedPreferences prefs;
    private TextView status, stockInfo;
    private Switch stockSwitch;
    private FrameLayout bar;
    private BatteryBadge badge;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(Frames.PREFS, MODE_PRIVATE);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(48), dp(20), dp(40));

        TextView title = new TextView(this);
        String ver = "";
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        title.setText("피카배터리  " + ver);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(title);

        status = new TextView(this);
        status.setPadding(0, dp(8), 0, dp(8));
        col.addView(status);

        Button open = new Button(this);
        open.setText("접근성 설정에서 켜기");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        col.addView(open);

        // 미리보기: 실제 상태바와 같은 뷰를 2배로 확대해서 보여줌
        TextView pvLabel = new TextView(this);
        pvLabel.setText("미리보기 (실제 상태바의 2배 크기)");
        pvLabel.setPadding(0, dp(24), 0, dp(6));
        col.addView(pvLabel);
        bar = new FrameLayout(this);
        bar.setBackgroundColor(0xFF222222);
        bar.setClipChildren(false);
        badge = new BatteryBadge(this, ZOOM);
        bar.addView(badge, new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL));
        col.addView(bar, new LinearLayout.LayoutParams(-1, statusBarHeight() * 2 + dp(40)));

        addSlider(col, "미리보기 배터리 %", 0, 100, 100, null, v -> badge.setLevel(v));
        Switch pvChg = new Switch(this);
        pvChg.setText("미리보기: 충전기 꽂기");
        pvChg.setPadding(0, dp(10), 0, dp(10));
        pvChg.setOnCheckedChangeListener((sw, c) -> badge.setCharging(c, true));
        col.addView(pvChg);

        addSlider(col, "캐릭터 크기 (dp)", 14, 40, Frames.D_SIZE, Frames.K_SIZE, null);
        addSlider(col, "오른쪽 여백 (dp)", 0, 160, Frames.D_RIGHT, Frames.K_RIGHT, null);
        addSlider(col, "세로 위치 보정 (dp, 0이 기본)", -10, 10, Frames.D_Y, Frames.K_Y, null);
        addSlider(col, "숫자 크기 (sp)", 5, 14, Frames.D_TEXT, Frames.K_TEXT, null);

        toggle(col, "배터리 숫자 표시", Frames.K_SHOW_NUM, true);
        toggle(col, "숫자 검정색 (밝은 상태바용)", Frames.K_DARK, false);
        toggle(col, "충전 중 전기 스파크", Frames.K_SPARK, true);

        TextView h = new TextView(this);
        h.setText("기본 배터리 아이콘 숨기기");
        h.setTextSize(16);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(0, dp(24), 0, dp(4));
        col.addView(h);
        stockInfo = new TextView(this);
        stockInfo.setTextIsSelectable(true);
        col.addView(stockInfo);
        stockSwitch = toggle(col, "기본 배터리 아이콘 숨기기", Frames.K_HIDE_STOCK, false);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);

        refreshPreview();
        prefs.registerOnSharedPreferenceChangeListener(this);
    }

    /** 설정이 바뀌면 미리보기에 바로 반영 */
    private void refreshPreview() {
        badge.applyPrefs(prefs);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) badge.getLayoutParams();
        lp.rightMargin = badge.dp(prefs.getInt(Frames.K_RIGHT, Frames.D_RIGHT));
        lp.topMargin = badge.dp(prefs.getInt(Frames.K_Y, Frames.D_Y));
        badge.setLayoutParams(lp);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) { refreshPreview(); }

    @Override
    protected void onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }

    private interface IntCb { void on(int v); }

    private void addSlider(LinearLayout col, String label, int min, int max, int def,
                           String key, IntCb cb) {
        TextView t = new TextView(this);
        t.setPadding(0, dp(16), 0, 0);
        col.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        int cur = key != null ? prefs.getInt(key, def) : def;
        sb.setProgress(cur - min);
        t.setText(label + " : " + cur);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean u) {
                int v = prog + min;
                t.setText(label + " : " + v);
                if (key != null) prefs.edit().putInt(key, v).apply();
                if (cb != null) cb.on(v);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        col.addView(sb);
    }

    private Switch toggle(LinearLayout col, String label, String key, boolean def) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setPadding(0, dp(10), 0, dp(10));
        sw.setChecked(prefs.getBoolean(key, def));
        sw.setOnCheckedChangeListener((s, c) -> prefs.edit().putBoolean(key, c).apply());
        col.addView(sw);
        return sw;
    }

    @Override
    protected void onResume() {
        super.onResume();
        String on = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean enabled = on != null && on.contains(getPackageName());
        status.setText(enabled
                ? "✅ 켜져 있어요. 상태바 오른쪽 위를 확인하세요."
                : "꺼져 있어요. 아래 버튼 → 설치된 앱 → 피카배터리 → 켜기");
        boolean can = StockIcon.canWrite(this);
        stockSwitch.setEnabled(can);
        stockInfo.setText(can
                ? "✅ 권한 있음. 켜면 기본 배터리 아이콘이 사라지고 캐릭터만 남아요. 앱(접근성)을 끄면 자동으로 원래대로 돌아와요."
                : "권한이 필요해요. PC에서 한 번만 실행하세요 (길게 눌러 복사):\nadb shell pm grant " + getPackageName()
                  + " android.permission.WRITE_SECURE_SETTINGS\n\n안 되면 굿락 QuickStar에서 배터리 아이콘을 꺼도 돼요.");
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }
}
