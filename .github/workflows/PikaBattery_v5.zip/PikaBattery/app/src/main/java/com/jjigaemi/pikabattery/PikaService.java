package com.jjigaemi.pikabattery;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.BatteryManager;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class PikaService extends AccessibilityService
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    private WindowManager wm;
    private BatteryBadge badge;
    private WindowManager.LayoutParams lp;
    private SharedPreferences prefs;
    private Boolean charging = null;
    private boolean receiverOn;

    private final BroadcastReceiver battery = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { readBattery(i); }
    };

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(Frames.PREFS, MODE_PRIVATE);
        badge = new BatteryBadge(this, 1f);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        applyPrefs(false);
        wm.addView(badge, lp);

        Intent sticky = registerReceiver(battery, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        receiverOn = true;
        if (sticky != null) readBattery(sticky);
        prefs.registerOnSharedPreferenceChangeListener(this);
        StockIcon.set(this, prefs.getBoolean(Frames.K_HIDE_STOCK, false));
    }

    private void readBattery(Intent i) {
        int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        int plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        if (l >= 0 && s > 0) badge.setLevel(Math.round(l * 100f / s));
        boolean now = plug != 0 || st == BatteryManager.BATTERY_STATUS_CHARGING;
        boolean first = charging == null;
        charging = now;
        badge.setCharging(now, !first);
    }

    private void applyPrefs(boolean relayout) {
        badge.applyPrefs(prefs);
        int size = badge.dp(prefs.getInt(Frames.K_SIZE, Frames.D_SIZE));
        int bar = statusBarHeight();
        badge.setMinimumHeight(bar);
        lp.height = Math.max(bar, size);
        lp.x = badge.dp(prefs.getInt(Frames.K_RIGHT, Frames.D_RIGHT));
        // 캐릭터가 상태바보다 크면 상태바 가운데에 오도록 위로 올림
        lp.y = badge.dp(prefs.getInt(Frames.K_Y, Frames.D_Y)) - Math.max(0, (size - bar) / 2);
        if (relayout && badge.isAttachedToWindow()) wm.updateViewLayout(badge, lp);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : badge.dp(24);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        if (Frames.K_HIDE_STOCK.equals(key)) StockIcon.set(this, sp.getBoolean(key, false));
        applyPrefs(true);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override
    public void onDestroy() {
        StockIcon.set(this, false);   // 앱이 꺼지면 기본 배터리 아이콘 복원
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
        if (receiverOn) { unregisterReceiver(battery); receiverOn = false; }
        if (badge != null && badge.isAttachedToWindow()) wm.removeView(badge);
        super.onDestroy();
    }
}
