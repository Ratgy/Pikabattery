package com.jjigaemi.pikabattery;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;
import java.util.ArrayList;
import java.util.Random;

/**
 * 충전 중 전기 연출.
 * behind=true  : 캐릭터 뒤에서 은은하게 숨쉬는 전기 오라
 * behind=false : 캐릭터 앞에서 지지직 움직이는 번개 줄기(가지 포함)
 */
public class SparkView extends View {
    private static final long FRAME = 33;          // 약 30fps로 번개 모양을 새로 그림
    private final boolean behind;
    private final Random rnd = new Random();
    private final Paint glow = stroke(0x8866DDFF);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mid = stroke(0xCCFFE14A);
    private final Paint core = stroke(0xFFFFFFFF);
    private final Paint aura = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<Bolt> bolts = new ArrayList<>();
    private boolean running;
    private long burstStart = -1, lastFrame;

    private static final class Bolt {
        float sx, sy, ex, ey;        // 시작·끝 (0~1 비율 좌표)
        float vx, vy;                // 끝점이 움직이는 속도 (줄기가 꿈틀댐)
        long born, life;
        boolean rising;              // 꽂는 순간 아래에서 위로 올라가는 줄기
        float[] pts;                 // 현재 프레임의 꺾인 점들
        ArrayList<float[]> forks = new ArrayList<>();
    }

    public SparkView(Context c, boolean behind) {
        super(c);
        this.behind = behind;
        setLayerType(LAYER_TYPE_HARDWARE, null);
    }

    private static Paint stroke(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(color);
        return p;
    }

    void start() { if (!running) { running = true; lastFrame = 0; postInvalidateOnAnimation(); } }
    void stop() { running = false; burstStart = -1; bolts.clear(); invalidate(); }
    void burst() { burstStart = SystemClock.uptimeMillis(); start(); }

    @Override
    protected void onDraw(Canvas c) {
        if (!running) return;
        long now = SystemClock.uptimeMillis();
        float w = getWidth(), h = getHeight(), s = Math.min(w, h);
        float burstT = burstStart < 0 ? 1f : (now - burstStart) / 900f;   // 0→1 동안 폭발 연출
        boolean bursting = burstT < 1f;

        if (behind) {
            // 숨쉬는 오라 + 꽂는 순간 번쩍
            float pulse = 0.55f + 0.25f * (float) Math.sin(now / 260.0) + rnd.nextFloat() * 0.12f;
            if (bursting) pulse += (1f - burstT) * 1.2f;
            int a = (int) Math.min(255, 110 * pulse);
            aura.setShader(new RadialGradient(w / 2, h * 0.58f, s * (0.42f + (bursting ? (1 - burstT) * 0.2f : 0)),
                    new int[]{(a << 24) | 0xFFF27A, ((a / 2) << 24) | 0x66DDFF, 0x0066DDFF},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(w / 2, h * 0.58f, s * 0.62f, aura);
            postInvalidateOnAnimation();
            return;
        }

        if (now - lastFrame >= FRAME) {
            lastFrame = now;
            update(now, bursting, burstT);
        }
        glow.setStrokeWidth(Math.max(3f, s * 0.11f));
        mid.setStrokeWidth(Math.max(1.6f, s * 0.045f));
        core.setStrokeWidth(Math.max(0.8f, s * 0.018f));

        Path p = new Path();
        for (Bolt b : bolts) {
            float age = (now - b.born) / (float) b.life;
            // 켜졌다 꺼지는 깜빡임 + 끝으로 갈수록 사라짐
            float alpha = age < 0.1f ? age / 0.1f : (age > 0.7f ? (1f - age) / 0.3f : 1f);
            alpha *= 0.8f + rnd.nextFloat() * 0.2f;
            if (alpha <= 0) continue;
            drawPoly(c, p, b.pts, w, h, alpha);
            for (float[] f : b.forks) drawPoly(c, p, f, w, h, alpha * 0.85f);
            // 줄기 끝에서 튀는 불꽃 알갱이
            int n = b.pts.length;
            float ex = b.pts[n - 2] * w, ey = b.pts[n - 1] * h;
            dot.setColor(0xFFFFF6A0);
            dot.setAlpha((int) (255 * Math.min(1, alpha)));
            for (int k = 0; k < 3; k++) {
                c.drawCircle(ex + (rnd.nextFloat() - 0.5f) * s * 0.18f,
                        ey + (rnd.nextFloat() - 0.5f) * s * 0.18f,
                        Math.max(1f, s * (0.012f + rnd.nextFloat() * 0.018f)), dot);
            }
        }
        postInvalidateOnAnimation();
    }

    private void drawPoly(Canvas c, Path p, float[] pts, float w, float h, float alpha) {
        p.reset();
        p.moveTo(pts[0] * w, pts[1] * h);
        for (int i = 2; i < pts.length; i += 2) p.lineTo(pts[i] * w, pts[i + 1] * h);
        int a = (int) (255 * Math.max(0, Math.min(1, alpha)));
        glow.setAlpha(a * 0x88 / 255); c.drawPath(p, glow);
        mid.setAlpha(a * 0xCC / 255);  c.drawPath(p, mid);
        core.setAlpha(a);              c.drawPath(p, core);
    }

    private void update(long now, boolean bursting, float burstT) {
        // 수명 끝난 줄기 제거
        for (int i = bolts.size() - 1; i >= 0; i--) {
            if (now - bolts.get(i).born > bolts.get(i).life) bolts.remove(i);
        }
        int target = bursting ? 6 : 3;
        while (bolts.size() < target && rnd.nextFloat() < (bursting ? 0.9f : 0.45f)) {
            bolts.add(spawn(now, bursting));
        }
        for (Bolt b : bolts) {
            // 끝점이 꿈틀대며 움직이고, 꽂는 순간 줄기는 위로 솟구침
            b.ex += b.vx; b.ey += b.vy;
            if (b.rising) { b.sy -= 0.02f; b.ey -= 0.03f; }
            b.pts = jag(b.sx, b.sy, b.ex, b.ey, 0.16f);
            b.forks.clear();
            int n = b.pts.length / 2;
            int forks = rnd.nextFloat() < 0.7f ? 1 + rnd.nextInt(2) : 0;
            for (int k = 0; k < forks; k++) {
                int i = 1 + rnd.nextInt(Math.max(1, n - 2));
                float fx = b.pts[i * 2], fy = b.pts[i * 2 + 1];
                double ang = Math.atan2(b.ey - b.sy, b.ex - b.sx) + (rnd.nextBoolean() ? 1 : -1) * (0.5 + rnd.nextFloat() * 0.6);
                float len = 0.1f + rnd.nextFloat() * 0.14f;
                b.forks.add(jag(fx, fy, fx + (float) Math.cos(ang) * len, fy + (float) Math.sin(ang) * len, 0.2f));
            }
        }
    }

    private Bolt spawn(long now, boolean bursting) {
        Bolt b = new Bolt();
        b.born = now;
        if (bursting) {
            b.rising = true;
            b.sx = 0.1f + rnd.nextFloat() * 0.8f; b.sy = 0.98f;
            b.ex = b.sx + (rnd.nextFloat() - 0.5f) * 0.3f; b.ey = 0.55f + rnd.nextFloat() * 0.15f;
            b.life = 250 + rnd.nextInt(200);
        } else {
            // 몸 가장자리에서 시작해 바깥으로 튀거나, 귀↔꼬리처럼 몸을 가로질러 튐
            double a1 = rnd.nextFloat() * Math.PI * 2;
            b.sx = 0.5f + (float) Math.cos(a1) * 0.28f; b.sy = 0.58f + (float) Math.sin(a1) * 0.3f;
            if (rnd.nextFloat() < 0.35f) {
                double a2 = a1 + Math.PI * (0.6 + rnd.nextFloat() * 0.8);
                b.ex = 0.5f + (float) Math.cos(a2) * 0.3f; b.ey = 0.58f + (float) Math.sin(a2) * 0.32f;
            } else {
                b.ex = 0.5f + (float) Math.cos(a1) * 0.48f; b.ey = 0.58f + (float) Math.sin(a1) * 0.46f;
            }
            b.life = 280 + rnd.nextInt(320);
        }
        b.vx = (rnd.nextFloat() - 0.5f) * 0.02f;
        b.vy = (rnd.nextFloat() - 0.5f) * 0.02f;
        return b;
    }

    /** 두 점 사이를 지그재그로 꺾은 번개 모양 (매 프레임 새로 만들어 지지직 움직임) */
    private float[] jag(float x0, float y0, float x1, float y1, float rough) {
        int seg = 6;
        float[] out = new float[(seg + 1) * 2];
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.hypot(dx, dy);
        float nx = -dy / Math.max(len, 1e-4f), ny = dx / Math.max(len, 1e-4f);
        for (int i = 0; i <= seg; i++) {
            float t = i / (float) seg;
            float off = (i == 0 || i == seg) ? 0 : (rnd.nextFloat() - 0.5f) * 2f * rough * len;
            out[i * 2] = x0 + dx * t + nx * off;
            out[i * 2 + 1] = y0 + dy * t + ny * off;
        }
        return out;
    }
}
