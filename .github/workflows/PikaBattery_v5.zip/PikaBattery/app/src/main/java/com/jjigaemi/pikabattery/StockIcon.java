package com.jjigaemi.pikabattery;

import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;

/** 기본 배터리 아이콘 숨김/복원 (adb로 WRITE_SECURE_SETTINGS 권한을 한 번 줘야 동작) */
final class StockIcon {
    private static final String KEY = "icon_blacklist";

    static boolean canWrite(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                == PackageManager.PERMISSION_GRANTED;
    }

    static void set(Context c, boolean hide) {
        if (!canWrite(c)) return;
        try {
            String cur = Settings.Secure.getString(c.getContentResolver(), KEY);
            StringBuilder out = new StringBuilder();
            if (cur != null) for (String s : cur.split(",")) {
                s = s.trim();
                if (s.isEmpty() || s.equals("battery")) continue;
                if (out.length() > 0) out.append(',');
                out.append(s);
            }
            if (hide) { if (out.length() > 0) out.append(','); out.append("battery"); }
            Settings.Secure.putString(c.getContentResolver(), KEY, out.toString());
        } catch (Exception ignored) { }
    }
}
