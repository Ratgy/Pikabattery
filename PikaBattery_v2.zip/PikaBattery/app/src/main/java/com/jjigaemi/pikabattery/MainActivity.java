package com.jjigaemi.pikabattery;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private TextView status;
    private ImageView previewImg;
    private TextView stockInfo;
    private Switch stockSwitch;
    private TextView previewNum;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(Frames.PREFS, MODE_PRIVATE);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        col.setPadding(p, dp(48), p, p);

        TextView title = new TextView(this);
        title.setText("피카배터리");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(title);

        status = new TextView(this);
        status.setPadding(0, dp(8), 0, dp(8));
        col.addView(status);

        Button open = new Button(this);
        open.setText("접근성 설정에서 켜기");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        col.addView(open);

        // 미리보기
        LinearLayout prev = new LinearLayout(this);
        prev.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        prev.setBackgroundColor(Color.parseColor("#222222"));
        prev.setPadding(dp(12), dp(12), dp(12), dp(12));
        previewNum = new TextView(this);
        previewNum.setTextColor(Color.WHITE);
        previewNum.setTypeface(Typeface.DEFAULT_BOLD);
        previewNum.setTextSize(14);
        prev.addView(previewNum);
        previewImg = new ImageView(this);
        prev.addView(previewImg, new LinearLayout.LayoutParams(dp(72), dp(72)));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.topMargin = dp(20);
        col.addView(prev, plp);
        addSlider(col, "미리보기 배터리 %", 0, 100, 100, null, v -> { pvLevel = v; preview(); });
        Switch pvChg = new Switch(this);
        pvChg.setText("미리보기: 충전 중");
        pvChg.setOnCheckedChangeListener((sw, c) -> { pvCharging = c; preview(); });
        col.addView(pvChg);
        preview();

        addSlider(col, "캐릭터 크기 (dp)", 14, 40, Frames.D_SIZE, Frames.K_SIZE, null);
        addSlider(col, "오른쪽 여백 (dp)", 0, 160, Frames.D_RIGHT, Frames.K_RIGHT, null);
        addSlider(col, "세로 위치 보정 (dp, 0이 기본)", -10, 10, Frames.D_Y, Frames.K_Y, null);
        addSlider(col, "숫자 크기 (sp)", 5, 14, Frames.D_TEXT, Frames.K_TEXT, null);

        toggle(col, "배터리 숫자 표시", Frames.K_SHOW_NUM, true);
        toggle(col, "숫자 검정색 (밝은 상태바용)", Frames.K_DARK, false);
        toggle(col, "충전 중 스파크 애니메이션", Frames.K_SPARK, true);
        toggle(col, "전체화면에서 같이 숨기기", Frames.K_HIDE_FULL, true);

        TextView h = new TextView(this);
        h.setText("기본 배터리 아이콘 숨기기");
        h.setTextSize(16);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(0, dp(24), 0, dp(4));
        col.addView(h);
        stockInfo = new TextView(this);
        stockInfo.setTextIsSelectable(true);
        col.addView(stockInfo);
        stockSwitch = toggle(col, "기본 배터리 아이콘 숨기기", Frames.K_HIDE_STOCK, false);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);
    }

    private interface IntCb { void on(int v); }

    private void addSlider(LinearLayout col, String label, int min, int max, int def,
                           String key, IntCb cb) {
        TextView t = new TextView(this);
        t.setPadding(0, dp(16), 0, 0);
        col.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        int cur = key != null ? prefs.getInt(key, def) : def;
        sb.setProgress(cur - min);
        t.setText(label + " : " + cur);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean u) {
                int v = prog + min;
                t.setText(label + " : " + v);
                if (key != null) prefs.edit().putInt(key, v).apply();
                if (cb != null) cb.on(v);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        col.addView(sb);
    }

    private int pvLevel = 100;
    private boolean pvCharging;

    private void preview() {
        int i = Frames.indexFor(pvLevel);
        previewImg.setImageResource(pvCharging ? Frames.CHG[i] : Frames.IDS[i]);
        previewNum.setText((pvCharging ? "⚡" : "") + pvLevel + " ");
    }

    private Switch toggle(LinearLayout col, String label, String key, boolean def) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setPadding(0, dp(10), 0, dp(10));
        sw.setChecked(prefs.getBoolean(key, def));
        sw.setOnCheckedChangeListener((s, c) -> prefs.edit().putBoolean(key, c).apply());
        col.addView(sw);
        return sw;
    }

    @Override
    protected void onResume() {
        super.onResume();
        String on = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean enabled = on != null && on.contains(getPackageName());
        status.setText(enabled
                ? "✅ 켜져 있어요. 상태바 오른쪽 위를 확인하세요."
                : "꺼져 있어요. 아래 버튼 → 설치된 앱 → 피카배터리 → 켜기");
        boolean can = StockIcon.canWrite(this);
        stockSwitch.setEnabled(can);
        stockInfo.setText(can
                ? "✅ 권한 있음. 켜면 기본 배터리 아이콘이 사라지고 피카츄만 남아요. 앱(접근성)을 끄면 자동으로 원래대로 돌아와요."
                : "권한이 필요해요. PC에서 한 번만 실행하세요 (길게 눌러 복사):\nadb shell pm grant " + getPackageName()
                  + " android.permission.WRITE_SECURE_SETTINGS\n\n안 되면 굿락 QuickStar에서 배터리 아이콘을 꺼도 돼요.");
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }
}
