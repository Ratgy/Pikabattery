package com.jjigaemi.pikabattery;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PikaService extends AccessibilityService
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    private WindowManager wm;
    private LinearLayout root;
    private FrameLayout stack;
    private TextView num;
    private ImageView normal, charge;
    private SparkView spark;
    private WindowManager.LayoutParams lp;
    private SharedPreferences prefs;
    private int level = -1;
    private Boolean charging = null;   // null = 아직 모름 (첫 값은 연출 없이 반영)
    private boolean receiverOn;

    private final BroadcastReceiver battery = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { readBattery(i); }
    };

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(Frames.PREFS, MODE_PRIVATE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setClipChildren(false);

        num = new TextView(this);
        num.setTypeface(Typeface.DEFAULT_BOLD);
        num.setIncludeFontPadding(false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.rightMargin = dp(1);
        root.addView(num, nlp);

        // 같은 자리에 기본/충전 캐릭터를 겹쳐 두고 투명도로 전환
        stack = new FrameLayout(this);
        stack.setClipChildren(false);
        normal = new ImageView(this);
        charge = new ImageView(this);
        spark = new SparkView(this);
        normal.setScaleType(ImageView.ScaleType.FIT_CENTER);
        charge.setScaleType(ImageView.ScaleType.FIT_CENTER);
        charge.setAlpha(0f);
        stack.addView(normal, new FrameLayout.LayoutParams(-1, -1));
        stack.addView(charge, new FrameLayout.LayoutParams(-1, -1));
        stack.addView(spark, new FrameLayout.LayoutParams(-1, -1));
        root.addView(stack, new LinearLayout.LayoutParams(dp(Frames.D_SIZE), dp(Frames.D_SIZE)));

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        // 전체화면(상태바 숨김)일 때 같이 숨기기 — Android 11+
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, in) -> {
                boolean barVisible = in.isVisible(WindowInsets.Type.statusBars());
                boolean hideFull = prefs.getBoolean(Frames.K_HIDE_FULL, true);
                stack.setVisibility(!hideFull || barVisible ? View.VISIBLE : View.INVISIBLE);
                num.setVisibility(!hideFull || barVisible ? numVis() : View.INVISIBLE);
                return in;
            });
        }

        applyPrefs(false);
        wm.addView(root, lp);

        Intent sticky = registerReceiver(battery, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        receiverOn = true;
        if (sticky != null) readBattery(sticky);
        prefs.registerOnSharedPreferenceChangeListener(this);
        StockIcon.set(this, prefs.getBoolean(Frames.K_HIDE_STOCK, false));
    }

    private int numVis() {
        return prefs.getBoolean(Frames.K_SHOW_NUM, true) ? View.VISIBLE : View.GONE;
    }

    private void readBattery(Intent i) {
        int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        int plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
        boolean now = plug != 0 || st == BatteryManager.BATTERY_STATUS_CHARGING;
        Boolean before = charging;
        charging = now;
        render();
        if (before == null) setChargeState(now, false);
        else if (before != now) setChargeState(now, true);
    }

    private void render() {
        if (normal == null || level < 0) return;
        int idx = Frames.indexFor(level);
        normal.setImageResource(Frames.IDS[idx]);
        charge.setImageResource(Frames.CHG[idx]);
        num.setText((Boolean.TRUE.equals(charging) ? "⚡" : "") + level);
    }

    /** 충전 상태 전환: 꽂으면 번쩍 + 전기가 아래에서 위로, 빼면 부드럽게 원래대로 */
    private void setChargeState(boolean on, boolean animate) {
        boolean sparksOn = prefs.getBoolean(Frames.K_SPARK, true);
        charge.animate().cancel();
        stack.animate().cancel();
        if (!animate) {
            charge.setAlpha(on ? 1f : 0f);
            normal.setAlpha(on ? 0f : 1f);
            if (on && sparksOn) spark.start(); else spark.stop();
            return;
        }
        if (on) {
            charge.animate().alpha(1f).setDuration(180).start();
            normal.animate().alpha(0f).setDuration(180).start();
            stack.setScaleX(1f); stack.setScaleY(1f);
            stack.animate().scaleX(1.18f).scaleY(1.18f).setDuration(120)
                    .withEndAction(() -> stack.animate().scaleX(1f).scaleY(1f).setDuration(220).start())
                    .start();
            if (sparksOn) spark.burst();
        } else {
            spark.stop();
            charge.animate().alpha(0f).setDuration(300).start();
            normal.animate().alpha(1f).setDuration(300).start();
        }
    }

    private void applyPrefs(boolean relayout) {
        int size = prefs.getInt(Frames.K_SIZE, Frames.D_SIZE);
        int right = prefs.getInt(Frames.K_RIGHT, Frames.D_RIGHT);
        int y = prefs.getInt(Frames.K_Y, Frames.D_Y);
        int text = prefs.getInt(Frames.K_TEXT, Frames.D_TEXT);
        boolean dark = prefs.getBoolean(Frames.K_DARK, false);

        LinearLayout.LayoutParams slp = (LinearLayout.LayoutParams) stack.getLayoutParams();
        slp.width = dp(size);
        slp.height = dp(size);
        stack.setLayoutParams(slp);

        num.setTextSize(TypedValue.COMPLEX_UNIT_SP, text);
        num.setTextColor(dark ? Color.BLACK : Color.WHITE);
        num.setShadowLayer(dp(1), 0, 0, dark ? 0x66FFFFFF : 0x99000000);
        num.setVisibility(numVis());

        int bar = statusBarHeight();
        root.setMinimumHeight(bar);
        lp.height = Math.max(bar, dp(size));
        lp.x = dp(right);
        lp.y = dp(y) - Math.max(0, (dp(size) - bar) / 2);

        if (charging != null) {
            if (charging && prefs.getBoolean(Frames.K_SPARK, true)) spark.start(); else spark.stop();
        }
        if (relayout && root.isAttachedToWindow()) wm.updateViewLayout(root, lp);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        if (Frames.K_HIDE_STOCK.equals(key)) StockIcon.set(this, sp.getBoolean(key, false));
        applyPrefs(true);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override
    public void onDestroy() {
        // 서비스가 꺼지면 기본 배터리 아이콘을 되돌려 놓음 (배터리 표시가 사라지는 일 방지)
        StockIcon.set(this, false);
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
        if (receiverOn) { unregisterReceiver(battery); receiverOn = false; }
        if (spark != null) spark.stop();
        if (root != null && root.isAttachedToWindow()) wm.removeView(root);
        super.onDestroy();
    }
}
