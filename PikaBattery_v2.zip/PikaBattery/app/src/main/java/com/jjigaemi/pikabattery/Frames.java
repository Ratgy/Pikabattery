package com.jjigaemi.pikabattery;

final class Frames {
    // 01 = 가득(100%) ... 20 = 바닥(0%)
    static final int[] IDS = { R.drawable.pika_01, R.drawable.pika_02, R.drawable.pika_03, R.drawable.pika_04, R.drawable.pika_05, R.drawable.pika_06, R.drawable.pika_07, R.drawable.pika_08, R.drawable.pika_09, R.drawable.pika_10, R.drawable.pika_11, R.drawable.pika_12, R.drawable.pika_13, R.drawable.pika_14, R.drawable.pika_15, R.drawable.pika_16, R.drawable.pika_17, R.drawable.pika_18, R.drawable.pika_19, R.drawable.pika_20 };
    // 충전 중 프레임 (같은 번호 = 같은 잔량 구간, 위치·크기 맞춤)
    static final int[] CHG = { R.drawable.pika_c_01, R.drawable.pika_c_02, R.drawable.pika_c_03, R.drawable.pika_c_04, R.drawable.pika_c_05, R.drawable.pika_c_06, R.drawable.pika_c_07, R.drawable.pika_c_08, R.drawable.pika_c_09, R.drawable.pika_c_10, R.drawable.pika_c_11, R.drawable.pika_c_12, R.drawable.pika_c_13, R.drawable.pika_c_14, R.drawable.pika_c_15, R.drawable.pika_c_16, R.drawable.pika_c_17, R.drawable.pika_c_18, R.drawable.pika_c_19, R.drawable.pika_c_20 };

    static int indexFor(int level) {
        if (level < 0) level = 0;
        if (level > 100) level = 100;
        return Math.min(19, (100 - level) / 5);
    }

    static final String PREFS = "pika";
    static final String K_SIZE = "size", K_RIGHT = "right", K_Y = "y", K_TEXT = "text";
    static final String K_DARK = "dark", K_SHOW_NUM = "num", K_SPARK = "spark";
    static final String K_HIDE_STOCK = "hideStock", K_HIDE_FULL = "hideFull";
    static final int D_SIZE = 24, D_RIGHT = 8, D_Y = 0, D_TEXT = 8;
}
